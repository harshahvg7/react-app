A basic react frontend to create a signature and mint it on opensea testnets
